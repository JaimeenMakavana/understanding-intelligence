import { create } from 'zustand';

export interface Topic {
  id: number;
  name: string;
  count: number;
  description: string;
  articles: Array<{
    id: number;
    title: string;
    excerpt: string;
    readTime: string;
    date: string;
    author: {
      name: string;
      avatar: string;
    };
    likes: number;
    comments: number;
  }>;
  relatedTopics: Array<{
    id: number;
    name: string;
    count: number;
  }>;
}

interface TopicStore {
  topics: Topic[];
  selectedTopic: Topic | null;
  setSelectedTopic: (topic: Topic | null) => void;
}

export const useTopicStore = create<TopicStore>((set) => ({
  topics: [
    {
      id: 1,
      name: "AI Tools",
      count: 245,
      description: "Explore the latest developments in artificial intelligence tools and their practical applications in various industries.",
      articles: [
        {
          id: 1,
          title: "Top 10 AI Tools for Developers in 2024",
          excerpt: "A comprehensive guide to the most powerful AI development tools that are reshaping the software industry.",
          readTime: "5 min",
          date: "2024-03-15",
          author: {
            name: "Alex Chen",
            avatar: "/avatars/alex.jpg"
          },
          likes: 156,
          comments: 23
        },
        {
          id: 2,
          title: "AI in Content Creation: A Game Changer",
          excerpt: "How artificial intelligence is revolutionizing the way we create and consume content.",
          readTime: "7 min",
          date: "2024-03-14",
          author: {
            name: "Sarah Johnson",
            avatar: "/avatars/sarah.jpg"
          },
          likes: 142,
          comments: 18
        }
      ],
      relatedTopics: [
        { id: 2, name: "Machine Learning", count: 189 },
        { id: 3, name: "Neural Networks", count: 167 }
      ]
    },
    // Add more topics as needed
  ],
  selectedTopic: null,
  setSelectedTopic: (topic) => set({ selectedTopic: topic })
}));