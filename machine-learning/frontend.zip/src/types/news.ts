export interface NewsSource {
  id: string;
  name: string;
  icon?: string;
  description?: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  description: string;
  source: NewsSource;
  publishedAt: string;
  imageUrl?: string;
  url: string;
}

export interface UserPreferences {
  selectedSources: string[];
  topics: string[];
  layout: 'grid' | 'list';
  theme: 'light' | 'dark';
}