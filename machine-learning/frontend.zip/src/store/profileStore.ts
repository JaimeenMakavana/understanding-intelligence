import { create } from "zustand";

interface ReadingStats {
  articlesRead: number;
  totalMinutes: number;
  averagePerDay: number;
  streak: number;
  topCategories: string[];
}

interface Preferences {
  sources: string[];
  topics: string[];
  readingTime: string;
  emailFrequency: string;
}

interface Achievement {
  title: string;
  icon: string;
  description: string;
  progress: number;
  date: string;
}

interface Activity {
  type: "completion" | "bookmark" | "highlight";
  title: string;
  timestamp: string;
  category: string;
}

interface UserData {
  name: string;
  role: string;
  avatar: string;
  joinDate: string;
  email: string;
  readingStats: ReadingStats;
  preferences: Preferences;
  achievements: Achievement[];
  recentActivity: Activity[];
}

interface ProfileStore {
  userData: UserData;
  setUserData: (data: UserData) => void;
}

export const useProfileStore = create<ProfileStore>((set) => ({
  userData: {
    name: "Alex Thompson",
    role: "Tech Enthusiast",
    avatar: "/profile-avatar.jpg",
    joinDate: "2023-11-15",
    email: "alex.t@example.com",
    readingStats: {
      articlesRead: 142,
      totalMinutes: 1268,
      averagePerDay: 18,
      streak: 15,
      topCategories: ["Technology", "Science", "Business"],
    },
    preferences: {
      sources: ["TechCrunch", "MIT Review", "Harvard Business Review"],
      topics: ["AI & ML", "Startups", "Innovation", "Climate Tech"],
      readingTime: "Morning",
      emailFrequency: "Daily",
    },
    achievements: [
      {
        title: "Early Bird",
        icon: "🌅",
        description: "Completed 10 articles before 9 AM",
        progress: 100,
        date: "2024-01-15",
      },
      {
        title: "Tech Savvy",
        icon: "💻",
        description: "Read 50 technology articles",
        progress: 80,
        date: "2024-01-10",
      },
      {
        title: "Consistent Reader",
        icon: "📚",
        description: "Maintained a 15-day reading streak",
        progress: 75,
        date: "2024-01-05",
      },
    ],
    recentActivity: [
      {
        type: "completion",
        title: "The Future of Quantum Computing",
        timestamp: "2024-01-20T10:30:00",
        category: "Technology",
      },
      {
        type: "bookmark",
        title: "Sustainable Energy Solutions",
        timestamp: "2024-01-19T15:45:00",
        category: "Environment",
      },
      {
        type: "highlight",
        title: "AI in Healthcare",
        timestamp: "2024-01-18T09:15:00",
        category: "Healthcare",
      },
    ],
  },
  setUserData: (data) => set({ userData: data }),
}));