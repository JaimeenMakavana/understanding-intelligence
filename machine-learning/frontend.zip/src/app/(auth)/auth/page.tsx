"use client";
import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FaGoogle, FaGithub } from "react-icons/fa";
import { useForm } from "react-hook-form";

// Define form data types
type SignInFormData = {
  email: string;
  password: string;
};

type SignUpFormData = {
  name: string;
  email: string;
  password: string;
};

export default function Auth() {
  const [isSignIn, setIsSignIn] = useState(true);
  const router = useRouter();
  const [error, setError] = useState("");

  // Setup form for sign in
  const signInForm = useForm<SignInFormData>({
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Setup form for sign up
  const signUpForm = useForm<SignUpFormData>({
    defaultValues: {
      name: "",
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: SignInFormData | SignUpFormData) => {
    try {
      setError("");
      if (isSignIn) {
        const response = await fetch("http://localhost:5000/api/auth/signin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to sign in");
        }

        const result = await response.json();
        // Store token in localStorage
        localStorage.setItem("token", result.token);
        router.push("/");
      } else {
        const response = await fetch("http://localhost:5000/api/auth/signup", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to sign up");
        }

        const result = await response.json();
        // Store token in localStorage
        localStorage.setItem("token", result.token);
        router.push("/");
      }
    } catch (error) {
      console.error("Authentication error:", error);
      setError(
        error instanceof Error ? error.message : "Authentication failed"
      );
    }
  };

  const handleFormSwitch = (mode: boolean) => {
    setIsSignIn(mode);
    setError("");
  };

  return (
    <div className="min-h-screen bg-[var(--background)] flex flex-col items-center px-4 py-8">
      <Link href="/" className="mb-8">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-500 to-blue-500">
          Readly
        </h1>
      </Link>

      <div className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md">
        <div className="flex justify-center mb-8">
          <div className="flex bg-gray-100 rounded-full p-1">
            <button
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                isSignIn
                  ? "bg-white text-gray-900 shadow"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => handleFormSwitch(true)}
              type="button"
            >
              Sign In
            </button>
            <button
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all ${
                !isSignIn
                  ? "bg-white text-gray-900 shadow"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => handleFormSwitch(false)}
              type="button"
            >
              Sign Up
            </button>
          </div>
        </div>

        {isSignIn ? (
          <form
            onSubmit={signInForm.handleSubmit(onSubmit)}
            className="space-y-4"
          >
            {error && (
              <div className="text-red-500 text-sm text-center mb-4">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                {...signInForm.register("email", {
                  required: "Email is required",
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: "Invalid email address",
                  },
                })}
                type="email"
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                placeholder="you@example.com"
              />
              {signInForm.formState.errors.email && (
                <p className="text-red-500 text-xs mt-1">
                  {signInForm.formState.errors.email.message}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                {...signInForm.register("password", {
                  required: "Password is required",
                  minLength: {
                    value: 6,
                    message: "Password must be at least 6 characters",
                  },
                })}
                type="password"
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                placeholder="••••••••"
              />
              {signInForm.formState.errors.password && (
                <p className="text-red-500 text-xs mt-1">
                  {signInForm.formState.errors.password.message}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-2 rounded-full hover:bg-indigo-700 transition mt-6"
            >
              Sign In
            </button>
          </form>
        ) : (
          <form
            onSubmit={signUpForm.handleSubmit(onSubmit)}
            className="space-y-4"
          >
            {error && (
              <div className="text-red-500 text-sm text-center mb-4">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Full Name
              </label>
              <input
                {...signUpForm.register("name", {
                  required: "Name is required",
                  minLength: {
                    value: 2,
                    message: "Name must be at least 2 characters",
                  },
                })}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                placeholder="John Doe"
              />
              {signUpForm.formState.errors.name && (
                <p className="text-red-500 text-xs mt-1">
                  {signUpForm.formState.errors.name.message}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                {...signUpForm.register("email", {
                  required: "Email is required",
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: "Invalid email address",
                  },
                })}
                type="email"
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                placeholder="you@example.com"
              />
              {signUpForm.formState.errors.email && (
                <p className="text-red-500 text-xs mt-1">
                  {signUpForm.formState.errors.email.message}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Password
              </label>
              <input
                {...signUpForm.register("password", {
                  required: "Password is required",
                  minLength: {
                    value: 6,
                    message: "Password must be at least 6 characters",
                  },
                })}
                type="password"
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition"
                placeholder="••••••••"
              />
              {signUpForm.formState.errors.password && (
                <p className="text-red-500 text-xs mt-1">
                  {signUpForm.formState.errors.password.message}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 text-white py-2 rounded-full hover:bg-indigo-700 transition mt-6"
            >
              Create Account
            </button>
          </form>
        )}

        <div className="mt-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">
                Or continue with
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 mt-6">
            <button
              type="button"
              className="flex items-center justify-center px-4 py-2 border border-gray-200 rounded-xl hover:bg-gray-50 transition"
            >
              <FaGoogle className="w-5 h-5 mr-2 text-gray-600" />
              Google
            </button>
            <button
              type="button"
              className="flex items-center justify-center px-4 py-2 border border-gray-200 rounded-xl hover:bg-gray-50 transition"
            >
              <FaGithub className="w-5 h-5 mr-2 text-gray-600" />
              GitHub
            </button>
          </div>
        </div>

        <p className="text-center text-sm text-gray-500 mt-8">
          {isSignIn ? "Don't have an account? " : "Already have an account? "}
          <button
            type="button"
            className="text-indigo-600 hover:text-indigo-500 font-medium"
            onClick={() => handleFormSwitch(!isSignIn)}
          >
            {isSignIn ? "Sign up" : "Sign in"}
          </button>
        </p>
      </div>
    </div>
  );
}
