import { NextResponse } from "next/server";

interface Topic {
  id: string;
  name: string;
  description: string;
  count: number;
  createdAt: Date;
  updatedAt: Date;
}

const topics: Topic[] = [];

// GET all topics
export async function GET() {
  return NextResponse.json(topics);
}

// POST new topic
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const newTopic: Topic = {
      id: Date.now().toString(),
      name: body.name,
      description: body.description,
      count: body.count || 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    topics.push(newTopic);
    return NextResponse.json(newTopic, { status: 201 });
  } catch {
    return NextResponse.json(
      { error: "Failed to create topic" },
      { status: 400 }
    );
  }
}
