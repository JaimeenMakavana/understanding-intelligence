"use client";

import { useState, useEffect } from "react";

interface Feature {
  _id: string;
  title: string;
  color: string;
  icon: string;
  createdAt: string;
  updatedAt: string;
}

interface FeatureForm {
  title: string;
  color: string;
  icon: string;
}

export default function FeaturesPage() {
  const [features, setFeatures] = useState<Feature[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string>("");
  const [currentFeature, setCurrentFeature] = useState<FeatureForm>({
    title: "",
    color: "",
    icon: "",
  });

  // Fetch features
  const fetchFeatures = async () => {
    try {
      setIsLoading(true);
      const response = await fetch("http://localhost:5000/api/features");
      if (!response.ok) throw new Error("Failed to fetch features");
      const data = await response.json();
      setFeatures(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch features");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchFeatures();
  }, []);

  // Handle form submission - will either create or update based on isEditing state
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (isEditing) {
      await handleUpdate(editingId);
    } else {
      await handleCreate();
    }
  };

  // Create feature
  const handleCreate = async () => {
    try {
      setError("");
      const response = await fetch("http://localhost:5000/api/features", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentFeature),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create feature");
      }

      await fetchFeatures();
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create feature");
    }
  };

  // Update feature
  const handleUpdate = async (id: string) => {
    try {
      setError("");
      const response = await fetch(`http://localhost:5000/api/features/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentFeature),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update feature");
      }

      await fetchFeatures();
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to update feature");
    }
  };

  // Delete feature
  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this feature?"))
      return;
    try {
      setError("");
      const response = await fetch(`http://localhost:5000/api/features/${id}`, {
        method: "DELETE",
      });
      if (!response.ok) throw new Error("Failed to delete feature");
      await fetchFeatures();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete feature");
    }
  };

  // Helper function to start editing a feature
  const startEditing = (feature: Feature) => {
    setIsEditing(true);
    setEditingId(feature._id);
    setCurrentFeature({
      title: feature.title,
      color: feature.color,
      icon: feature.icon,
    });
  };

  // Helper function to reset the form
  const resetForm = () => {
    setIsEditing(false);
    setEditingId("");
    setCurrentFeature({ title: "", color: "", icon: "" });
  };

  if (isLoading && features.length === 0)
    return <div className="p-8">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Manage Features</h1>

        {/* Form */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">
            {isEditing ? "Edit Feature" : "Add New Feature"}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                type="text"
                value={currentFeature.title}
                onChange={(e) =>
                  setCurrentFeature({
                    ...currentFeature,
                    title: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Color
              </label>
              <input
                type="text"
                value={currentFeature.color}
                onChange={(e) =>
                  setCurrentFeature({
                    ...currentFeature,
                    color: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Icon URL
              </label>
              <input
                type="text"
                value={currentFeature.icon}
                onChange={(e) =>
                  setCurrentFeature({ ...currentFeature, icon: e.target.value })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                {isEditing ? "Update" : "Create"}
              </button>
              {isEditing && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Features List */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {features.length === 0 ? (
            <p className="p-6 text-center text-gray-500">
              No features found. Create your first feature above.
            </p>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Color
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Icon
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {features.map((feature) => (
                  <tr key={feature._id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {feature.title}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div
                          className="w-6 h-6 rounded-full mr-2"
                          style={{ backgroundColor: feature.color }}
                        ></div>
                        {feature.color}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {feature.icon}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => startEditing(feature)}
                        className="text-indigo-600 hover:text-indigo-900 mr-4"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(feature._id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Error Display */}
        {error && (
          <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}
      </div>
    </div>
  );
}
