"use client";
import { useState } from "react";
import Link from "next/link";
import { FiSearch, FiTrendingUp, FiBookOpen } from "react-icons/fi";

const MOCK_TOPICS = [
  {
    id: 1,
    name: "AI Tools",
    description: "Latest advancements and tools in artificial intelligence.",
    count: 245,
    slug: "ai-tools",
  },
  {
    id: 2,
    name: "Web3",
    description: "Explore the decentralized web and blockchain innovations.",
    count: 189,
    slug: "web3",
  },
  {
    id: 3,
    name: "Creator Economy",
    description: "Insights and trends for creators and digital entrepreneurs.",
    count: 167,
    slug: "creator-economy",
  },
  {
    id: 4,
    name: "Healthcare Innovation",
    description: "Breakthroughs and news in health tech and medicine.",
    count: 142,
    slug: "healthcare-innovation",
  },
  {
    id: 5,
    name: "Future of Work",
    description: "Remote work, productivity, and the evolving workplace.",
    count: 128,
    slug: "future-of-work",
  },
  {
    id: 6,
    name: "Sustainable Tech",
    description: "Green technology and sustainable solutions.",
    count: 113,
    slug: "sustainable-tech",
  },
];

export default function TopicsPage() {
  const [search, setSearch] = useState("");

  const filteredTopics = MOCK_TOPICS.filter(
    (topic) =>
      topic.name.toLowerCase().includes(search.toLowerCase()) ||
      topic.description.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[var(--background)] py-8 px-4 flex flex-col items-center">
      <div className="w-full max-w-2xl">
        <header className="mb-8 flex flex-col items-center">
          <h1 className="text-3xl font-extrabold text-gray-900 mb-2 flex items-center gap-2">
            <FiTrendingUp className="text-indigo-600" />
            Explore Trending Topics
          </h1>
          <p className="text-gray-500 text-center max-w-lg">
            Discover the most popular topics, curated for your interests. Click
            any topic to dive deeper and explore the latest articles and
            insights.
          </p>
        </header>

        <div className="mb-6 flex items-center bg-white rounded-full shadow px-4 py-2 max-w-lg mx-auto">
          <FiSearch className="text-gray-400 mr-2" />
          <input
            type="text"
            placeholder="Search topics..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm text-gray-700"
            aria-label="Search topics"
          />
        </div>

        <section>
          {filteredTopics.length === 0 ? (
            <div className="text-center text-gray-400 py-16">
              <FiBookOpen className="mx-auto mb-2 text-3xl" />
              <div>No topics found. Try a different search.</div>
            </div>
          ) : (
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {filteredTopics.map((topic) => (
                <li key={topic.id}>
                  <Link
                    href={`/topics/${topic.slug}`}
                    className="block bg-white rounded-2xl shadow-md hover:shadow-lg transition-shadow p-6 h-full group"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-indigo-600 font-semibold text-sm group-hover:underline">
                        {topic.name}
                      </span>
                      <span className="text-xs text-gray-400">
                        {topic.count} articles
                      </span>
                    </div>
                    <p className="text-gray-600 text-xs mb-2 line-clamp-2">
                      {topic.description}
                    </p>
                    <span className="inline-block text-[10px] text-gray-400 group-hover:text-indigo-600 transition-colors">
                      View articles &rarr;
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </div>
  );
}
