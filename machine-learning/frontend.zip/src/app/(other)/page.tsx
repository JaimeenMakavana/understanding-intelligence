"use client";
import { FeaturesGrid } from "@/components/home/FeaturesGrid";
import { HeroSection } from "@/components/home/HeroSection";
import { RecentHighlights } from "@/components/home/RecentHighlights";
import { TrendingTopics } from "@/components/home/TrendingTopics";

export default function Home() {
  return (
    <div className="flex flex-col items-center px-4 py-8 space-y-10">
      <HeroSection />
      <FeaturesGrid />
      <TrendingTopics />
      <RecentHighlights />
    </div>
  );
}
