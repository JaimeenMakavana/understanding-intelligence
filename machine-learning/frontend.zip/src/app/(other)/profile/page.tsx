"use client";

import { useProfileStore } from "@/store/profileStore";
import Image from "next/image";
import { useState } from "react";
import AvatarImg from "@/statics/images/avatar.jpeg";
// Add these interfaces at the top of the file
interface ReadingStats {
  articlesRead: number;
  totalMinutes: number;
  averagePerDay: number;
  streak: number;
  topCategories: string[];
}

interface Preferences {
  sources: string[];
  topics: string[];
  readingTime: string;
  emailFrequency: string;
}

interface Achievement {
  title: string;
  icon: string;
  description: string;
  progress: number;
  date: string;
}

interface Activity {
  type: "completion" | "bookmark" | "highlight";
  title: string;
  timestamp: string;
  category: string;
}

interface UserData {
  name: string;
  role: string;
  avatar: string;
  joinDate: string;
  email: string;
  readingStats: ReadingStats;
  preferences: Preferences;
  achievements: Achievement[];
  recentActivity: Activity[];
}

// Update component props interfaces
interface TabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

interface StatItemProps {
  label: string;
  value: string | number;
}

interface CategoryItemProps {
  category: string;
  opacity: number;
}

interface PreferenceListProps {
  title: string;
  items: string[];
}

interface PreferenceTagsProps {
  title: string;
  tags: string[];
}

interface AchievementCardProps {
  achievement: Achievement;
}

interface ActivityItemProps {
  activity: Activity;
}

// Update the userData constant type
const userData: UserData = {
  name: "Alex Thompson",
  role: "Tech Enthusiast",
  avatar: "/profile-avatar.jpg",
  joinDate: "2023-11-15",
  email: "alex.t@example.com",
  readingStats: {
    articlesRead: 142,
    totalMinutes: 1268,
    averagePerDay: 18,
    streak: 15,
    topCategories: ["Technology", "Science", "Business"],
  },
  preferences: {
    sources: ["TechCrunch", "MIT Review", "Harvard Business Review"],
    topics: ["AI & ML", "Startups", "Innovation", "Climate Tech"],
    readingTime: "Morning",
    emailFrequency: "Daily",
  },
  achievements: [
    {
      title: "Early Bird",
      icon: "🌅",
      description: "Completed 10 articles before 9 AM",
      progress: 100,
      date: "2024-01-15",
    },
    {
      title: "Tech Savvy",
      icon: "💻",
      description: "Read 50 technology articles",
      progress: 80,
      date: "2024-01-10",
    },
    {
      title: "Consistent Reader",
      icon: "📚",
      description: "Maintained a 15-day reading streak",
      progress: 75,
      date: "2024-01-05",
    },
  ],
  recentActivity: [
    {
      type: "completion",
      title: "The Future of Quantum Computing",
      timestamp: "2024-01-20T10:30:00",
      category: "Technology",
    },
    {
      type: "bookmark",
      title: "Sustainable Energy Solutions",
      timestamp: "2024-01-19T15:45:00",
      category: "Environment",
    },
    {
      type: "highlight",
      title: "AI in Healthcare",
      timestamp: "2024-01-18T09:15:00",
      category: "Healthcare",
    },
  ],
};

export default function Profile() {
  const [activeTab, setActiveTab] = useState("stats");
  const userData = useProfileStore((state) => state.userData);

  const renderStats = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-white rounded-3xl shadow-lg p-6">
        <h3 className="text-lg font-bold mb-4">Reading Statistics</h3>
        <div className="space-y-4">
          <StatItem
            label="Articles Read"
            value={userData.readingStats.articlesRead}
          />
          <StatItem
            label="Total Minutes"
            value={userData.readingStats.totalMinutes}
          />
          <StatItem
            label="Current Streak"
            value={`🔥 ${userData.readingStats.streak} days`}
          />
        </div>
      </div>
      <div className="bg-white rounded-3xl shadow-lg p-6">
        <h3 className="text-lg font-bold mb-4">Top Categories</h3>
        <div className="space-y-3">
          {userData.readingStats.topCategories.map((category, index) => (
            <CategoryItem
              key={category}
              category={category}
              opacity={1 - index * 0.2}
            />
          ))}
        </div>
      </div>
    </div>
  );

  const renderPreferences = () => (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <h3 className="text-lg font-bold mb-6">Reading Preferences</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <PreferenceList
          title="Favorite Sources"
          items={userData.preferences.sources}
        />
        <PreferenceTags
          title="Preferred Topics"
          tags={userData.preferences.topics}
        />
      </div>
    </div>
  );

  const renderAchievements = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {userData.achievements.map((achievement) => (
        <AchievementCard key={achievement.title} achievement={achievement} />
      ))}
    </div>
  );

  const renderActivity = () => (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <h3 className="text-lg font-bold mb-6">Recent Activity</h3>
      <div className="space-y-6">
        {userData.recentActivity.map((activity, index) => (
          <ActivityItem key={index} activity={activity} />
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[var(--background)] py-8">
      <div className="px-4 sm:px-6 lg:px-8">
        <ProfileHeader />
        <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />
        {activeTab === "stats" && renderStats()}
        {activeTab === "preferences" && renderPreferences()}
        {activeTab === "achievements" && renderAchievements()}
        {activeTab === "activity" && renderActivity()}
      </div>
    </div>
  );
}

function ProfileHeader() {
  return (
    <div className="bg-white rounded-3xl shadow-xl p-8 mb-8 max-w-xs mx-auto hover:shadow-2xl transition-all duration-300 ease-in-out">
      <div className="flex flex-col items-center text-center space-y-4">
        {/* Avatar Section */}
        <div className="relative w-24 h-24 mb-4">
          <Image
            src={AvatarImg}
            alt={userData.name}
            layout="fill"
            className="rounded-full object-cover"
          />
          <div className="absolute bottom-0 right-0 w-6 h-6 bg-green-400 rounded-full border-2 border-white shadow-md" />
        </div>

        {/* Name and Role Section */}
        <div className="space-y-2">
          <h1 className="text-2xl font-semibold text-gray-800 mb-1 hover:text-indigo-600 transition duration-200 ease-in-out">
            {userData.name}
          </h1>
          <p className="text-sm text-gray-600">{userData.role}</p>
          <p className="text-xs text-gray-500">
            Member since {new Date(userData.joinDate).toLocaleDateString()}
          </p>
        </div>

        {/* Edit Button */}
        <button className="px-6 py-2 bg-indigo-600 text-white rounded-full shadow-lg hover:bg-indigo-700 hover:scale-105 transform transition duration-200 ease-in-out">
          Edit Profile
        </button>
      </div>
    </div>
  );
}

function Tabs({ activeTab, setActiveTab }: TabsProps) {
  const tabs = ["stats", "preferences", "achievements", "activity"];
  return (
    <div className="flex gap-4 mb-4 overflow-x-auto max-w-xs py-2">
      {tabs.map((tab) => (
        <button
          key={tab}
          onClick={() => setActiveTab(tab)}
          className={`px-6 py-2 rounded-full text-sm font-semibold transition-all ${
            activeTab === tab
              ? "bg-white shadow-md text-indigo-600"
              : "text-gray-600 hover:bg-white hover:shadow hover:text-indigo-600"
          }`}
        >
          {tab.charAt(0).toUpperCase() + tab.slice(1)}
        </button>
      ))}
    </div>
  );
}

function StatItem({ label, value }: StatItemProps) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-gray-600">{label}</span>
      <span className="text-2xl font-bold text-indigo-600">{value}</span>
    </div>
  );
}

function CategoryItem({ category, opacity }: CategoryItemProps) {
  return (
    <div className="flex items-center gap-2">
      <div className="w-1 h-8 bg-indigo-600 rounded-full" style={{ opacity }} />
      <span className="text-gray-600">{category}</span>
    </div>
  );
}

function PreferenceList({ title, items }: PreferenceListProps) {
  return (
    <div>
      <h4 className="font-semibold mb-3">{title}</h4>
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item} className="flex items-center gap-2 text-gray-600">
            <span className="w-2 h-2 bg-indigo-600 rounded-full" />
            {item}
          </div>
        ))}
      </div>
    </div>
  );
}

function PreferenceTags({ title, tags }: PreferenceTagsProps) {
  return (
    <div>
      <h4 className="font-semibold mb-3">{title}</h4>
      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <span
            key={tag}
            className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-sm"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
}

function AchievementCard({ achievement }: AchievementCardProps) {
  return (
    <div className="bg-white rounded-3xl shadow-lg p-6">
      <div className="text-4xl mb-4">{achievement.icon}</div>
      <h3 className="font-bold mb-2">{achievement.title}</h3>
      <p className="text-sm text-gray-600 mb-4">{achievement.description}</p>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className="bg-indigo-600 h-2 rounded-full transition-all"
          style={{ width: `${achievement.progress}%` }}
        />
      </div>
    </div>
  );
}

function ActivityItem({ activity }: ActivityItemProps) {
  const getActivityColor = (type: Activity["type"]): string => {
    if (type === "completion") return "bg-green-100 text-green-600";
    if (type === "bookmark") return "bg-blue-100 text-blue-600";
    return "bg-yellow-100 text-yellow-600";
  };

  const getActivityIcon = (type: Activity["type"]): string => {
    if (type === "completion") return "✓";
    if (type === "bookmark") return "🔖";
    return "✨";
  };

  return (
    <div className="flex items-start gap-4">
      <div
        className={`w-8 h-8 rounded-full flex items-center justify-center ${getActivityColor(
          activity.type
        )}`}
      >
        {getActivityIcon(activity.type)}
      </div>
      <div className="flex-grow">
        <p className="font-semibold">{activity.title}</p>
        <p className="text-sm text-gray-600">
          {new Date(activity.timestamp).toLocaleString()}
        </p>
      </div>
    </div>
  );
}
