import { useRouter } from "next/navigation";
import { FiClock, FiArrowRight, FiBookmark, FiShare2 } from "react-icons/fi";
import { useEffect, useState } from "react";

interface HighlightItemProps {
  title: string;
  subtitle: string;
  readTime: string;
  date: string;
  category: string;
  bookmarked: boolean;
  shares: number;
  topicSlug: string;
  onClick: () => void;
}

interface Highlight {
  _id: string;
  title: string;
  subtitle: string;
  readTime: string;
  date: string;
  category: string;
  bookmarked: boolean;
  shares: number;
  topicSlug: string;
}

function HighlightItem({
  title,
  subtitle,
  readTime,
  date,
  category,
  bookmarked,
  shares,
  onClick,
}: HighlightItemProps) {
  return (
    <div
      onClick={onClick}
      className="p-4 rounded-xl hover:bg-gray-50 transition-all cursor-pointer border border-transparent hover:border-gray-100 hover:shadow-sm"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-2 py-1 rounded-full hover:bg-indigo-100 transition-colors">
          {category}
        </span>
        <span className="text-xs text-gray-400">{date}</span>
      </div>

      <h4 className="text-sm font-semibold text-gray-800 mb-1 line-clamp-2">
        {title}
      </h4>
      <p className="text-xs text-gray-500 mb-3 line-clamp-2">{subtitle}</p>

      <div className="flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center space-x-4">
          <span className="flex items-center">
            <FiClock className="w-3 h-3 mr-1" />
            {readTime}
          </span>
          <span className="flex items-center">
            <FiShare2 className="w-3 h-3 mr-1" />
            {shares}
          </span>
        </div>
        <button
          className={`${
            bookmarked
              ? "text-indigo-600"
              : "text-gray-400 hover:text-indigo-600"
          } transition-colors`}
        >
          <FiBookmark className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

export function RecentHighlights() {
  const router = useRouter();
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchHighlights = async () => {
      try {
        const response = await fetch(
          "http://localhost:5000/api/highlights/recent"
        );
        if (!response.ok) {
          throw new Error("Failed to fetch highlights");
        }
        const data = await response.json();
        setHighlights(data);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to load highlights"
        );
      } finally {
        setIsLoading(false);
      }
    };

    fetchHighlights();
  }, []);

  const handleHighlightClick = (topicSlug: string) => {
    router.push(`/topics/${topicSlug}`);
  };

  if (isLoading) {
    return (
      <section className="bg-white p-6 rounded-3xl shadow-md w-full max-w-md space-y-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-bold text-gray-800">Recent Highlights</h3>
          <span className="text-xs text-gray-400">Last 3 days</span>
        </div>
        <div className="space-y-3">
          {[...Array(3)].map((_, index) => (
            <div
              key={index}
              className="p-4 rounded-xl border border-gray-100 animate-pulse"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="w-20 h-6 bg-gray-200 rounded-full"></div>
                <div className="w-24 h-4 bg-gray-200 rounded"></div>
              </div>
              <div className="w-full h-4 bg-gray-200 rounded mb-2"></div>
              <div className="w-3/4 h-4 bg-gray-200 rounded"></div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="bg-white p-6 rounded-3xl shadow-md w-full max-w-md">
        <div className="text-center text-red-500">
          <p>Error: {error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 text-sm text-indigo-600 hover:text-indigo-800"
          >
            Try again
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="bg-white p-6 rounded-3xl shadow-md w-full max-w-md space-y-4">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-lg font-bold text-gray-800">Recent Highlights</h3>
        <span className="text-xs text-gray-400">Last 3 days</span>
      </div>

      <div className="space-y-3">
        {highlights.map((highlight) => (
          <HighlightItem
            key={highlight._id}
            {...highlight}
            onClick={() => handleHighlightClick(highlight.topicSlug)}
          />
        ))}
      </div>

      <button
        onClick={() => router.push("/topics")}
        className="w-full bg-gray-100 py-2.5 rounded-full text-xs font-medium text-gray-700 hover:bg-gray-200 transition-all flex items-center justify-center group"
      >
        Discover More Highlights
        <FiArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
      </button>
    </section>
  );
}
