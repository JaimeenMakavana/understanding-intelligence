import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  images: {
    domains: ["www.flaticon.com", "cdn-icons-png.flaticon.com"],
  },
};

export default nextConfig;
