"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";

export default function SavedPage() {
  const router = useRouter();

  const savedArticles = [
    {
      id: 1,
      title: "The Evolution of AI in 2024",
      category: "Technology",
      image: "/ai-evolution.jpg",
      readProgress: 70,
      tags: ["AI", "Innovation", "Future"],
    },
    {
      id: 2,
      title: "Sustainable Finance Trends",
      category: "Finance",
      image: "/sustainable-finance.jpg",
      readProgress: 40,
      tags: ["Finance", "ESG", "Sustainability"],
    },
    {
      id: 3,
      title: "Future of Remote Work",
      category: "Workplace",
      image: "/remote-work.jpg",
      readProgress: 20,
      tags: ["Remote Work", "Technology", "Trends"],
    },
  ];

  return (
    <div className="min-h-screen px-4 py-10">
      {/* Header */}
      <div className="max-w-6xl mx-auto text-center mb-16">
        <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-700 via-purple-600 to-pink-600 mb-4">
          Your Saved Knowledge
        </h1>
        <p className="text-gray-600 text-md max-w-xl mx-auto">
          Keep track of insights you&apos;ve bookmarked for future growth and
          action.
        </p>
      </div>

      {/* Stats */}
      <div className="max-w-6xl mx-auto grid gap-6 sm:grid-cols-2 md:grid-cols-3 mb-16">
        <div className="bg-white/40 backdrop-blur-md rounded-3xl p-6 shadow hover:shadow-xl transition-all">
          <h2 className="text-3xl font-bold text-indigo-700">
            {savedArticles.length}
          </h2>
          <p className="text-sm text-gray-600 mt-2">Articles Saved</p>
        </div>
        <div className="bg-white/40 backdrop-blur-md rounded-3xl p-6 shadow hover:shadow-xl transition-all">
          <h2 className="text-3xl font-bold text-purple-700">
            {Math.round(
              savedArticles.reduce((a, b) => a + b.readProgress, 0) /
                savedArticles.length
            )}
            %
          </h2>
          <p className="text-sm text-gray-600 mt-2">Avg. Read Progress</p>
        </div>
        <div className="bg-white/40 backdrop-blur-md rounded-3xl p-6 shadow hover:shadow-xl transition-all">
          <h2 className="text-3xl font-bold text-pink-700">
            {savedArticles.filter((a) => a.readProgress === 100).length}
          </h2>
          <p className="text-sm text-gray-600 mt-2">Completed Reads</p>
        </div>
      </div>

      {/* Saved Articles */}
      <div className="max-w-6xl mx-auto grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {savedArticles.map((article) => (
          <div
            key={article.id}
            className="bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-all cursor-pointer flex flex-col group hover:-translate-y-1"
            onClick={() => router.push(`/insights/${article.id}`)}
          >
            {/* Image */}
            <div className="relative h-56 w-full overflow-hidden">
              <Image
                src={article.image}
                alt={article.title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-300"
              />
            </div>

            {/* Content */}
            <div className="p-6 flex-1 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-medium text-indigo-600 bg-indigo-100/60 ring-1 ring-indigo-300 px-3 py-1 rounded-full group-hover:ring-2 transition-all">
                  {article.category}
                </span>
                <span className="text-xs text-gray-400">
                  {article.readProgress}% read
                </span>
              </div>

              <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2">
                {article.title}
              </h3>

              {/* Progress Bar */}
              <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full"
                  style={{ width: `${article.readProgress}%` }}
                />
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {article.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-white/40 backdrop-blur-md ring-1 ring-gray-300 text-gray-700 px-2 py-1 rounded-full"
                  >
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Continue Reading (optional) */}
              {article.readProgress > 0 && article.readProgress < 100 && (
                <button
                  className="mt-auto text-indigo-600 text-sm font-semibold hover:underline"
                  onClick={(e) => {
                    e.stopPropagation();
                    router.push(`/insights/${article.id}`);
                  }}
                >
                  Continue Reading →
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
