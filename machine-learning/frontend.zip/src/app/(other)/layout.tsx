import RootlayoutWrapper from "@/components/layouts/root-layout-wrapper";
import React from "react";

const RootLayout = ({ children }: { children: React.ReactNode }) => {
  return <RootlayoutWrapper>{children}</RootlayoutWrapper>;
};

export default RootLayout;
