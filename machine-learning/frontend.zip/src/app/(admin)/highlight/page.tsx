"use client";

import { useState, useEffect } from "react";

interface Highlight {
  _id: string;
  title: string;
  subtitle: string;
  readTime: string;
  category: string;
  bookmarked: boolean;
  shares: number;
  topicSlug: string;
  createdAt: string;
  updatedAt: string;
}

interface HighlightForm {
  title: string;
  subtitle: string;
  readTime: string;
  category: string;
  bookmarked: boolean;
  shares: number;
  topicSlug: string;
}

export default function HighlightPage() {
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string>("");
  const [currentHighlight, setCurrentHighlight] = useState<HighlightForm>({
    title: "",
    subtitle: "",
    readTime: "",
    category: "",
    bookmarked: false,
    shares: 0,
    topicSlug: "",
  });

  // Fetch highlights
  const fetchHighlights = async () => {
    try {
      setIsLoading(true);
      const response = await fetch("http://localhost:5000/api/highlights");
      if (!response.ok) throw new Error("Failed to fetch highlights");
      const data = await response.json();
      setHighlights(data);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to fetch highlights"
      );
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchHighlights();
  }, []);

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing) {
      await handleUpdate(editingId);
    } else {
      await handleCreate();
    }
  };

  // Create highlight
  const handleCreate = async () => {
    try {
      setError("");
      const response = await fetch("http://localhost:5000/api/highlights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(currentHighlight),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create highlight");
      }

      await fetchHighlights();
      resetForm();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to create highlight"
      );
    }
  };

  // Update highlight
  const handleUpdate = async (id: string) => {
    try {
      setError("");
      const response = await fetch(
        `http://localhost:5000/api/highlights/${id}`,
        {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(currentHighlight),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update highlight");
      }

      await fetchHighlights();
      resetForm();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to update highlight"
      );
    }
  };

  // Delete highlight
  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this highlight?"))
      return;
    try {
      setError("");
      const response = await fetch(
        `http://localhost:5000/api/highlights/${id}`,
        {
          method: "DELETE",
        }
      );
      if (!response.ok) throw new Error("Failed to delete highlight");
      await fetchHighlights();
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to delete highlight"
      );
    }
  };

  // Start editing a highlight
  const startEditing = (highlight: Highlight) => {
    setIsEditing(true);
    setEditingId(highlight._id);
    setCurrentHighlight({
      title: highlight.title,
      subtitle: highlight.subtitle,
      readTime: highlight.readTime,
      category: highlight.category,
      bookmarked: highlight.bookmarked,
      shares: highlight.shares,
      topicSlug: highlight.topicSlug,
    });
  };

  // Reset form
  const resetForm = () => {
    setIsEditing(false);
    setEditingId("");
    setCurrentHighlight({
      title: "",
      subtitle: "",
      readTime: "",
      category: "",
      bookmarked: false,
      shares: 0,
      topicSlug: "",
    });
  };

  if (isLoading && highlights.length === 0)
    return <div className="p-8">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Manage Highlights</h1>

        {/* Form */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">
            {isEditing ? "Edit Highlight" : "Add New Highlight"}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                type="text"
                value={currentHighlight.title}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    title: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Subtitle
              </label>
              <input
                type="text"
                value={currentHighlight.subtitle}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    subtitle: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Read Time
              </label>
              <input
                type="text"
                value={currentHighlight.readTime}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    readTime: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
                placeholder="e.g., 5 min read"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <input
                type="text"
                value={currentHighlight.category}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    category: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Topic Slug
              </label>
              <input
                type="text"
                value={currentHighlight.topicSlug}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    topicSlug: e.target.value,
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={currentHighlight.bookmarked}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    bookmarked: e.target.checked,
                  })
                }
                className="mr-2"
              />
              <label className="text-sm font-medium text-gray-700">
                Bookmarked
              </label>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Shares
              </label>
              <input
                type="number"
                value={currentHighlight.shares}
                onChange={(e) =>
                  setCurrentHighlight({
                    ...currentHighlight,
                    shares: parseInt(e.target.value),
                  })
                }
                className="w-full px-4 py-2 rounded-lg border focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div className="flex gap-2">
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
              >
                {isEditing ? "Update" : "Create"}
              </button>
              {isEditing && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Highlights List */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          {highlights.length === 0 ? (
            <p className="p-6 text-center text-gray-500">
              No highlights found. Create your first highlight above.
            </p>
          ) : (
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Category
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Read Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Shares
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {highlights.map((highlight) => (
                  <tr key={highlight._id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          {highlight.title}
                        </div>
                        <div className="text-sm text-gray-500">
                          {highlight.subtitle}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-indigo-100 text-indigo-800">
                        {highlight.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {highlight.readTime}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {highlight.shares}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={() => startEditing(highlight)}
                        className="text-indigo-600 hover:text-indigo-900 mr-4"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(highlight._id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Error Display */}
        {error && (
          <div className="mt-4 p-4 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}
      </div>
    </div>
  );
}
