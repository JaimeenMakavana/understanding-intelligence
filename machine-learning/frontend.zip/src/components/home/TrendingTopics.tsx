import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";

interface Topic {
  id: string;
  name: string;
  description: string;
  count: number;
}

export function TrendingTopics() {
  const [showAllTopics, setShowAllTopics] = useState(false);
  const [topics, setTopics] = useState<Topic[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchTopics = async () => {
      try {
        const response = await fetch(
          "http://localhost:5000/api/trending-topics"
        );
        if (!response.ok) throw new Error("Failed to fetch topics");
        const data = await response.json();
        setTopics(data);
      } catch (error) {
        console.error("Error fetching topics:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTopics();
  }, []);

  const displayedTopics = showAllTopics ? topics : topics.slice(0, 4);

  const handleTopicSelect = (topicId: string) => {
    const topic = topics.find((t) => t.id === topicId);
    if (topic) {
      router.push(`/topics/${topic.name.toLowerCase().replace(/\s+/g, "-")}`);
    }
  };

  if (isLoading) {
    return (
      <section className="bg-white p-6 rounded-3xl shadow-md w-full max-w-md">
        <p>Loading topics...</p>
      </section>
    );
  }

  return (
    <section className="bg-white p-6 rounded-3xl shadow-md w-full max-w-md space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs text-gray-400 uppercase tracking-wide">
          Trending Topics
        </p>
        <button
          className="text-[10px] text-gray-500 hover:text-indigo-600 underline transition-colors"
          onClick={() => setShowAllTopics(!showAllTopics)}
        >
          {showAllTopics ? "Show Less" : "View All"}
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {displayedTopics.map((topic) => (
          <button
            key={topic.id}
            onClick={() => handleTopicSelect(topic.id)}
            className="text-xs px-3 py-1 rounded-full transition-all
              bg-gray-100 text-gray-700 hover:bg-indigo-100 hover:text-indigo-700"
          >
            <span>{topic.name}</span>
            <span className="ml-1 text-[10px] opacity-60">({topic.count})</span>
          </button>
        ))}
      </div>
    </section>
  );
}
