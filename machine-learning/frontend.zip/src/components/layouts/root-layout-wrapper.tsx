"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { HiMenu, HiX } from "react-icons/hi";
import API_BASE_URL from '@/config/api';

export default function RootlayoutWrapper({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigationItems = [
    { name: "Home", path: "/" },
    { name: "Insights", path: "/insights" },
    { name: "Saved", path: "/saved" },
    { name: "Profile", path: "/profile" },
  ];

  const [email, setEmail] = useState("");
  const [subscribeStatus, setSubscribeStatus] = useState<
    "idle" | "loading" | "success" | "error"
  >("idle");
  const [statusMessage, setStatusMessage] = useState("");

  const handleSubscribe = async () => {
    try {
      setSubscribeStatus('loading');
      const response = await fetch(`${API_BASE_URL}/api/subscription`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Failed to subscribe");
      }

      setSubscribeStatus("success");
      setStatusMessage("Successfully subscribed!");
      setEmail("");
    } catch (error) {
      setSubscribeStatus("error");
      setStatusMessage(
        error instanceof Error ? error.message : "Failed to subscribe"
      );
    }
  };

  return (
    <div className="min-h-screen bg-[var(--background)] flex flex-col items-center px-4 py-8">
      {/* Logo and Mobile Menu */}
      <div className="w-full flex items-center justify-between md:justify-center mb-6 max-w-xs">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-500 to-blue-500">
          Readly
        </h1>
        <button
          className="md:hidden text-2xl text-gray-600"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <HiX /> : <HiMenu />}
        </button>
      </div>

      {/* Navigation - Mobile Drawer */}
      <div
        className={`md:hidden fixed top-0 right-0 h-full w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out ${
          isMenuOpen ? "translate-x-0" : "translate-x-full"
        } z-50`}
      >
        <div className="p-6">
          <div className="flex justify-end mb-6">
            <button
              onClick={() => setIsMenuOpen(false)}
              className="text-2xl text-gray-600"
            >
              <HiX />
            </button>
          </div>
          <div className="flex flex-col space-y-4">
            {navigationItems.map((item) => (
              <Link
                key={item.path}
                href={item.path}
                className={`px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  item.path === pathname
                    ? "bg-indigo-50 text-indigo-600"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Overlay */}
      {isMenuOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 bg-opacity-50 z-40"
          onClick={() => setIsMenuOpen(false)}
        />
      )}

      {/* Navigation - Desktop */}
      <div className="hidden md:flex space-x-4 mb-3 max-w-xs overflow-x-auto py-2">
        {navigationItems.map((item) => (
          <Link
            key={item.path}
            href={item.path}
            className={`px-4 py-2 rounded-full text-sm font-semibold transition-all ${
              item.path === pathname
                ? "bg-white shadow-md text-indigo-600"
                : "text-gray-600 hover:bg-white hover:shadow hover:text-indigo-600"
            }`}
          >
            {item.name}
          </Link>
        ))}
      </div>

      {children}

      {/* Subscribe */}
      <div className="bg-white p-6 rounded-3xl shadow-lg w-full max-w-xs text-center">
        <h3 className="text-lg font-bold mb-2">Stay Updated</h3>
        <p className="text-gray-600 text-sm mb-4">
          Get tailored reading insights delivered to your inbox.
        </p>
        <input
          type="email"
          placeholder="Enter your email"
          className="w-full p-2 mb-4 border rounded-md text-sm"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button
          className={`w-full bg-indigo-600 text-white py-2 rounded-full hover:bg-indigo-700 transition ${
            subscribeStatus === "loading" ? "opacity-70 cursor-not-allowed" : ""
          }`}
          onClick={handleSubscribe}
          disabled={subscribeStatus === "loading"}
        >
          {subscribeStatus === "loading" ? "Subscribing..." : "Subscribe"}
        </button>
        {statusMessage && (
          <p
            className={`text-xs mt-2 ${
              subscribeStatus === "success" ? "text-green-500" : "text-red-500"
            }`}
          >
            {statusMessage}
          </p>
        )}
        <p className="text-xs text-gray-400 mt-2">Already 1,200 subscribers</p>
      </div>
      {/* Footer CTA */}
      <footer className="pt-8 text-center text-gray-400 text-xs">
        Made for curious minds. Built with ❤️
      </footer>
    </div>
  );
}
