import Image from "next/image";
import { useEffect, useState } from "react";

interface Feature {
  _id: string;
  title: string;
  color: string;
  icon: string;
}

export function FeaturesGrid() {
  const [features, setFeatures] = useState<Feature[]>([]);
  console.log("features::: ", features);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchFeatures = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/features");
        if (!response.ok) {
          throw new Error("Failed to fetch features");
        }
        const data = await response.json();
        setFeatures(data);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to load features"
        );
      } finally {
        setIsLoading(false);
      }
    };

    fetchFeatures();
  }, []);

  if (isLoading) {
    return (
      <section className="grid grid-cols-2 gap-4 w-full max-w-md">
        {[...Array(4)].map((_, idx) => (
          <div
            key={idx}
            className="rounded-2xl p-6 bg-gray-100 animate-pulse flex flex-col items-center justify-center text-center shadow-sm h-32"
          />
        ))}
      </section>
    );
  }

  if (error) {
    return (
      <section className="w-full max-w-md text-center p-6">
        <p className="text-red-500">Error: {error}</p>
      </section>
    );
  }

  return (
    <section className="grid grid-cols-2 gap-4 w-full max-w-md">
      {features.map((feature) => (
        <div
          key={feature._id}
          className={`rounded-2xl p-6 bg-gradient-to-br ${feature.color} flex flex-col items-center justify-center text-center shadow-sm`}
        >
          <div className="relative w-12 h-12 rounded-md overflow-hidden">
            <Image
              src={feature.icon}
              alt={feature.title}
              fill
              className="object-contain"
            />
          </div>
          <h4 className="font-semibold text-sm mt-2">{feature.title}</h4>
        </div>
      ))}
    </section>
  );
}
