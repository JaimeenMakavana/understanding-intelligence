"use client";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useTopicStore } from "@/store/topicStore";
import { useEffect } from "react";
import Image from "next/image";
import {
  FiClock,
  FiHeart,
  FiMessageCircle,
  FiArrowRight,
} from "react-icons/fi";
import { FiArrowLeft } from "react-icons/fi";

export default function TopicPage() {
  const params = useParams();
  const topicSlug = params.slug as string;
  const { topics, selectedTopic, setSelectedTopic } = useTopicStore();

  useEffect(() => {
    const topic = topics.find(
      (t) => t.name.toLowerCase().replace(/\s+/g, "-") === topicSlug
    );
    setSelectedTopic(topic || null);
  }, [topicSlug, topics, setSelectedTopic]);

  if (!selectedTopic) {
    return (
      <div className="min-h-screen flex flex-col items-center px-4 py-8">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-3xl shadow-md p-8 text-center">
            <div className="mb-6">
              <FiMessageCircle className="w-16 h-16 mx-auto text-gray-400" />
            </div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">
              Topic Not Found
            </h2>
            <p className="text-gray-600 mb-6">
              We couldn&apos;t find the topic you&apos;re looking for. It might
              have been moved or doesn&apos;t exist.
            </p>
            <div className="space-y-3">
              <Link
                href="/"
                className="block w-full bg-indigo-600 text-white py-2 rounded-full hover:bg-indigo-700 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                Return to Homepage
              </Link>
              <button
                onClick={() => window.history.back()}
                className="block w-full bg-gray-100 text-gray-700 py-2 rounded-full hover:bg-gray-200 transition-all transform hover:scale-[1.02] active:scale-[0.98]"
              >
                Go Back
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center px-4 py-8 space-y-8">
      <div className="w-full max-w-2xl">
        <Link
          href="/"
          className="text-sm text-gray-500 hover:text-indigo-600 mb-4 inline-flex items-center group"
        >
          <FiArrowLeft className="mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to Home
        </Link>

        {/* Topic Header */}
        <div className="bg-white rounded-3xl shadow-md p-8 mb-8">
          <h1 className="text-3xl font-bold mb-4">{selectedTopic.name}</h1>
          <p className="text-gray-600 mb-4">{selectedTopic.description}</p>
          <div className="flex items-center text-sm text-gray-500">
            <span className="mr-4">{selectedTopic.count} articles</span>
            <span>Updated daily</span>
          </div>
        </div>

        {/* Articles Section */}
        <div className="space-y-6">
          <h2 className="text-xl font-semibold mb-4">Latest Articles</h2>
          {selectedTopic.articles.map((article) => (
            <article
              key={article.id}
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center mb-4">
                <Image
                  src={article.author.avatar}
                  alt={article.author.name}
                  width={40}
                  height={40}
                  className="rounded-full"
                />
                <div className="ml-3">
                  <p className="text-sm font-medium">{article.author.name}</p>
                  <p className="text-xs text-gray-500">{article.date}</p>
                </div>
              </div>
              <h3 className="text-lg font-semibold mb-2">{article.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{article.excerpt}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <span className="flex items-center">
                    <FiClock className="mr-1" />
                    {article.readTime}
                  </span>
                  <span className="flex items-center">
                    <FiHeart className="mr-1" />
                    {article.likes}
                  </span>
                  <span className="flex items-center">
                    <FiMessageCircle className="mr-1" />
                    {article.comments}
                  </span>
                </div>
                <button className="text-indigo-600 hover:text-indigo-700 flex items-center text-sm font-medium">
                  Read more
                  <FiArrowRight className="ml-1" />
                </button>
              </div>
            </article>
          ))}
        </div>

        {/* Related Topics */}
        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-4">Related Topics</h2>
          <div className="flex flex-wrap gap-2">
            {selectedTopic.relatedTopics.map((topic) => (
              <Link
                key={topic.id}
                href={`/topics/${topic.name
                  .toLowerCase()
                  .replace(/\s+/g, "-")}`}
                className="px-4 py-2 bg-gray-100 rounded-full text-sm text-gray-700 hover:bg-indigo-100 hover:text-indigo-700 transition-colors"
              >
                {topic.name}
                <span className="ml-1 text-xs opacity-60">({topic.count})</span>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
