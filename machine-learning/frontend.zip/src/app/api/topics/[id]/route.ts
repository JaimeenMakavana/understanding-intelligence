import { NextResponse } from "next/server";

// Define a strong type for your topics
interface Topic {
  id: string;
  title: string;
  description?: string;
  createdAt: Date;
  updatedAt: Date;
  [key: string]: unknown; // For any additional properties
}

// Use a more robust data structure (this would be replaced with a database in production)
const topics: Topic[] = [
  // Your topics would go here
];

// GET single topic
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
): Promise<NextResponse> {
  try {
    if (!params?.id) {
      return NextResponse.json(
        { error: "Missing required id parameter" },
        { status: 400 }
      );
    }

    const topic = topics.find((t) => t.id === params.id);
    if (!topic) {
      return NextResponse.json({ error: "Topic not found" }, { status: 404 });
    }

    return NextResponse.json(topic);
  } catch (error) {
    console.error("Error fetching topic:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// Define expected shape of update request
interface UpdateTopicRequest {
  title?: string;
  description?: string;
  [key: string]: unknown;
}

// PUT update topic
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
): Promise<NextResponse> {
  try {
    if (!params?.id) {
      return NextResponse.json(
        { error: "Missing required id parameter" },
        { status: 400 }
      );
    }

    const body = (await request.json()) as UpdateTopicRequest;

    // Validate required fields if any
    if (body.title !== undefined && typeof body.title !== "string") {
      return NextResponse.json(
        { error: "Title must be a string" },
        { status: 400 }
      );
    }

    const index = topics.findIndex((t) => t.id === params.id);
    if (index === -1) {
      return NextResponse.json({ error: "Topic not found" }, { status: 404 });
    }

    // Safely update only allowed fields
    const updatedTopic: Topic = {
      ...topics[index],
      ...(body.title !== undefined ? { title: body.title } : {}),
      ...(body.description !== undefined
        ? { description: body.description }
        : {}),
      updatedAt: new Date(),
    };

    topics[index] = updatedTopic;

    return NextResponse.json(updatedTopic);
  } catch (error) {
    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: "Invalid JSON in request body" },
        { status: 400 }
      );
    }

    console.error("Error updating topic:", error);
    return NextResponse.json(
      { error: "Failed to update topic" },
      { status: 500 }
    );
  }
}

// DELETE topic
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
): Promise<NextResponse> {
  try {
    if (!params?.id) {
      return NextResponse.json(
        { error: "Missing required id parameter" },
        { status: 400 }
      );
    }

    const index = topics.findIndex((t) => t.id === params.id);
    if (index === -1) {
      return NextResponse.json({ error: "Topic not found" }, { status: 404 });
    }

    topics.splice(index, 1);

    return new NextResponse(null, { status: 204 });
  } catch (error) {
    console.error("Error deleting topic:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
