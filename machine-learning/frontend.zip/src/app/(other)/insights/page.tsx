"use client";

import { useRouter } from "next/navigation";
import Image from "next/image";

export default function Insights() {
  const router = useRouter();

  const insights = [
    {
      id: 1,
      title: "The Evolution of AI in 2024",
      category: "Technology",
      readTime: "5 min read",
      image: "/ai-evolution.jpg",
      excerpt:
        "Exploring the latest breakthroughs in artificial intelligence and their impact on various industries.",
      author: "Dr. Sarah Chen",
      date: "2024-01-20",
      tags: ["AI", "Innovation", "Future"],
    },
    {
      id: 2,
      title: "Sustainable Finance Trends",
      category: "Finance",
      readTime: "4 min read",
      image: "/sustainable-finance.jpg",
      excerpt:
        "How ESG investments are shaping the future of global financial markets.",
      author: "Michael Roberts",
      date: "2024-01-19",
      tags: ["Finance", "ESG", "Sustainability"],
    },
    {
      id: 3,
      title: "Future of Remote Work",
      category: "Workplace",
      readTime: "6 min read",
      image: "/remote-work.jpg",
      excerpt:
        "New trends and technologies enabling distributed teams to collaborate effectively.",
      author: "Emma Watson",
      date: "2024-01-18",
      tags: ["Remote Work", "Technology", "Trends"],
    },
  ];

  const categories = [
    "All",
    "Technology",
    "Finance",
    "Workplace",
    "Health",
    "Culture",
    "AI",
    "Innovation",
    "ESG",
    "Future of Work",
  ];

  return (
    <div className="min-h-screen  px-4 py-10">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-16 text-center">
        <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-700 via-purple-600 to-indigo-600 mb-4">
          Curated Insights for the Visionaries
        </h1>
        <p className="text-gray-600 text-md max-w-2xl mx-auto">
          Stay ahead with daily intelligence in technology, finance, and the
          future of work. Personalized to your ambitions.
        </p>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-4 justify-center mb-12">
        {categories.map((category) => (
          <button
            key={category}
            className="px-5 py-2 rounded-full text-sm font-semibold transition-all
              hover:bg-indigo-50 hover:text-indigo-700 bg-white text-gray-700 border border-gray-200"
          >
            {category}
          </button>
        ))}
      </div>

      {/* Insights Grid */}
      <div className="max-w-6xl mx-auto grid gap-8 md:grid-cols-2 lg:grid-cols-3">
        {insights.map((insight) => (
          <div
            key={insight.id}
            className="bg-white rounded-3xl overflow-hidden shadow-md hover:shadow-2xl transition-shadow cursor-pointer flex flex-col"
            onClick={() => router.push(`/insights/${insight.id}`)}
          >
            {/* Image */}
            <div className="relative h-56 w-full">
              <Image
                src={insight.image}
                alt={insight.title}
                fill
                className="object-cover"
              />
            </div>

            {/* Content */}
            <div className="p-6 flex-1 flex flex-col">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-medium text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full">
                  {insight.category}
                </span>
                <span className="text-xs text-gray-400">
                  {insight.readTime}
                </span>
              </div>

              <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2">
                {insight.title}
              </h3>

              <p className="text-gray-600 text-sm line-clamp-3 mb-4">
                {insight.excerpt}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {insight.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-xs bg-gray-100 text-gray-500 px-2 py-1 rounded-full"
                  >
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Author Info */}
              <div className="mt-auto flex items-center justify-between text-xs text-gray-500">
                <span>{insight.author}</span>
                <span>
                  {new Date(insight.date).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                  })}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CTA Section */}
      <div className="max-w-6xl mx-auto mt-20 bg-gradient-to-r from-indigo-500 to-purple-500 p-10 rounded-3xl text-white flex flex-col md:flex-row items-center justify-between">
        <div className="mb-6 md:mb-0">
          <h2 className="text-2xl font-bold mb-2">
            Get Personalized Insight Alerts
          </h2>
          <p className="text-sm opacity-90">
            Subscribe to get curated content directly aligned with your
            professional growth goals.
          </p>
        </div>
        <button className="bg-white text-indigo-700 px-6 py-3 rounded-full font-semibold hover:bg-gray-100 transition-all">
          Subscribe Now
        </button>
      </div>
    </div>
  );
}
